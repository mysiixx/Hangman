# Hangman

This is a hangman game coded in Java.
It takes a random word everytime you run the program.

The word list is in Estonian.
